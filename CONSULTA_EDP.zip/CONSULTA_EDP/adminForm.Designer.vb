﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adminForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CriticScore = New System.Windows.Forms.Button()
        Me.DeveloperRating = New System.Windows.Forms.Button()
        Me.GameSales = New System.Windows.Forms.Button()
        Me.GameName = New System.Windows.Forms.Button()
        Me.usrCount = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.DarkOrange
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(959, 13)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(100, 28)
        Me.btnClose.TabIndex = 15
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.DarkOrange
        Me.Label2.Font = New System.Drawing.Font("MS Reference Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(489, 25)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(394, 42)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Management System"
        '
        'CriticScore
        '
        Me.CriticScore.BackColor = System.Drawing.Color.DimGray
        Me.CriticScore.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.CriticScore.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveBorder
        Me.CriticScore.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CriticScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CriticScore.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.CriticScore.Location = New System.Drawing.Point(40, 379)
        Me.CriticScore.Margin = New System.Windows.Forms.Padding(4)
        Me.CriticScore.Name = "CriticScore"
        Me.CriticScore.Size = New System.Drawing.Size(267, 54)
        Me.CriticScore.TabIndex = 13
        Me.CriticScore.Text = "Critic Score"
        Me.CriticScore.UseVisualStyleBackColor = False
        '
        'DeveloperRating
        '
        Me.DeveloperRating.BackColor = System.Drawing.Color.DimGray
        Me.DeveloperRating.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DeveloperRating.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeveloperRating.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.DeveloperRating.Location = New System.Drawing.Point(40, 304)
        Me.DeveloperRating.Margin = New System.Windows.Forms.Padding(4)
        Me.DeveloperRating.Name = "DeveloperRating"
        Me.DeveloperRating.Size = New System.Drawing.Size(267, 54)
        Me.DeveloperRating.TabIndex = 12
        Me.DeveloperRating.Text = "Developer Rating"
        Me.DeveloperRating.UseVisualStyleBackColor = False
        '
        'GameSales
        '
        Me.GameSales.BackColor = System.Drawing.Color.DimGray
        Me.GameSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GameSales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameSales.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GameSales.Location = New System.Drawing.Point(40, 228)
        Me.GameSales.Margin = New System.Windows.Forms.Padding(4)
        Me.GameSales.Name = "GameSales"
        Me.GameSales.Size = New System.Drawing.Size(267, 54)
        Me.GameSales.TabIndex = 11
        Me.GameSales.Text = "Game Sales"
        Me.GameSales.UseVisualStyleBackColor = False
        '
        'GameName
        '
        Me.GameName.BackColor = System.Drawing.Color.DimGray
        Me.GameName.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GameName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameName.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GameName.Location = New System.Drawing.Point(40, 83)
        Me.GameName.Margin = New System.Windows.Forms.Padding(4)
        Me.GameName.Name = "GameName"
        Me.GameName.Size = New System.Drawing.Size(267, 49)
        Me.GameName.TabIndex = 10
        Me.GameName.Text = "Game Name"
        Me.GameName.UseVisualStyleBackColor = False
        '
        'usrCount
        '
        Me.usrCount.BackColor = System.Drawing.Color.DimGray
        Me.usrCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.usrCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.usrCount.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.usrCount.Location = New System.Drawing.Point(40, 157)
        Me.usrCount.Margin = New System.Windows.Forms.Padding(4)
        Me.usrCount.Name = "usrCount"
        Me.usrCount.Size = New System.Drawing.Size(267, 49)
        Me.usrCount.TabIndex = 9
        Me.usrCount.Text = "User Score Count"
        Me.usrCount.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS Reference Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(141, 25)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(332, 42)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Game Infomation"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DimGray
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Button1.Location = New System.Drawing.Point(40, 453)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(267, 54)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "Import"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DimGray
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Button2.Location = New System.Drawing.Point(40, 531)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(267, 54)
        Me.Button2.TabIndex = 17
        Me.Button2.Text = "Backup"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DimGray
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Button3.Location = New System.Drawing.Point(40, 609)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(267, 54)
        Me.Button3.TabIndex = 18
        Me.Button3.Text = "Reports"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(362, 92)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(683, 571)
        Me.DataGridView1.TabIndex = 19
        '
        'adminForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(1072, 694)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CriticScore)
        Me.Controls.Add(Me.DeveloperRating)
        Me.Controls.Add(Me.GameSales)
        Me.Controls.Add(Me.GameName)
        Me.Controls.Add(Me.usrCount)
        Me.Controls.Add(Me.Label1)
        Me.Name = "adminForm"
        Me.Text = "adminForm"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnClose As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents CriticScore As Button
    Friend WithEvents DeveloperRating As Button
    Friend WithEvents GameSales As Button
    Friend WithEvents GameName As Button
    Friend WithEvents usrCount As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents DataGridView1 As DataGridView
End Class
