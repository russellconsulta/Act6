﻿Imports MySql.Data.MySqlClient

Public Class ListofgamesForm
    Private Sub ListofgamesForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        adminForm.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "Insert into game_name values('" _
                & .gamesnametxt.Text & "', '" _
                & .yeartxt.Text & "', '" _
                & .genretxt.Text & "', '" _
                & .publishertxt.Text & "')"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Added!")
                Call Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Clear_Boxes()
        With Me
            .gamesnametxt.Text = vbNullString
            .yeartxt.Text = ""
            .genretxt.Text = ""
            .publishertxt.Text = ""
        End With
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "Update game_name set name = '" _
                & .gamesnametxt.Text & "' where year_release = '" _
                & .yeartxt.Text & "' and genre = '" _
                & .genretxt.Text & "' and publisher = '" _
                & .publishertxt.Text & "'"

                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Updated")
                Call Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                Dim answer As MsgBoxResult
                answer = MsgBox("Are you sure you want to delete this record", MsgBoxStyle.YesNo)
                If answer = MsgBoxResult.Yes Then
                    strSQL = "Delete from game_name" _
                                    & " where name = '" _
                                    & .gamesnametxt.Text & "'"
                    mycmd.CommandText = strSQL
                    mycmd.Connection = myconn
                    mycmd.ExecuteNonQuery()
                    MsgBox("Record Successfully Deleted")
                    Call Clear_Boxes()
                End If

            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Me.DataGridView1.Rows.Clear()
        Dim strsql As String
        Dim mycommand As New MySqlCommand
        strsql = "Select * from game_name"
        Connect_to_DB()
        With mycommand
            .Connection = myconn
            .CommandType = CommandType.Text
            .CommandText = strsql
        End With
        Dim myreader As MySqlDataReader
        myreader = mycommand.ExecuteReader

        If DataGridView1.Columns.Count = 0 Then
            DataGridView1.Columns.Add("name", "Game Name")
            DataGridView1.Columns.Add("year_release", "Year Release")
            DataGridView1.Columns.Add("genre", "Genre")
            DataGridView1.Columns.Add("publisher", "Publisher")
        End If
        While myreader.Read()
            Me.DataGridView1.Rows.Add(New Object() {myreader.Item("name"), myreader.Item("year_release"), myreader.Item("genre"), myreader.Item("publisher")})
        End While
        Disconnect_to_DB()
    End Sub
End Class