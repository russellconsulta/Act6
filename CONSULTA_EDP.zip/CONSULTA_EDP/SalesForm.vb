﻿Imports MySql.Data.MySqlClient

Public Class SalesForm
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        adminForm.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "Insert into game_sales values('" _
                & .gametxt.Text & "', '" _
                & .nasaletxt.Text & "', '" _
                & .eusaletx.Text & "', '" _
                & .jptext.Text & "')"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Added!")
                Call Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Clear_Boxes()
        With Me
            .gametxt.Text = vbNullString
            .nasaletxt.Text = ""
            .eusaletx.Text = ""
            .jptext.Text = ""
        End With
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "Update game_sales set Game_name = '" _
                & .gametxt.Text & "' where na_sales = '" _
                & .nasaletxt.Text & "' and eu_sales = '" _
                & .eusaletx.Text & "' and jp_sales = '" _
                & .jptext.Text & "'"

                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Updated")
                Call Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                Dim answer As MsgBoxResult
                answer = MsgBox("Are you sure you want to delete this record", MsgBoxStyle.YesNo)
                If answer = MsgBoxResult.Yes Then
                    strSQL = "Delete from game_sales" _
                                    & " where Game_name = '" _
                                    & .gametxt.Text & "'"
                    mycmd.CommandText = strSQL
                    mycmd.Connection = myconn
                    mycmd.ExecuteNonQuery()
                    MsgBox("Record Successfully Deleted")
                    Call Clear_Boxes()
                End If

            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Me.DataGridView1.Rows.Clear()
        Dim strsql As String
        Dim mycommand As New MySqlCommand
        strsql = "Select * from game_sales"
        Connect_to_DB()
        With mycommand
            .Connection = myconn
            .CommandType = CommandType.Text
            .CommandText = strsql
        End With
        Dim myreader As MySqlDataReader
        myreader = mycommand.ExecuteReader

        If DataGridView1.Columns.Count = 0 Then
            DataGridView1.Columns.Add("Game_name", "Game Name")
            DataGridView1.Columns.Add("na_sales", "NA Sales")
            DataGridView1.Columns.Add("eu_sales", "EU Sales")
            DataGridView1.Columns.Add("jp_sales", "JP Sales")
        End If
        While myreader.Read()
            Me.DataGridView1.Rows.Add(New Object() {myreader.Item("Game_name"), myreader.Item("na_sales"), myreader.Item("eu_sales"), myreader.Item("jp_sales")})
        End While
        Disconnect_to_DB()
    End Sub
End Class