﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class adminForm
    Private Sub GameName_Click(sender As Object, e As EventArgs) Handles GameName.Click
        Me.Hide()
        ListofgamesForm.Show()
    End Sub

    Private Sub usrCount_Click(sender As Object, e As EventArgs) Handles usrCount.Click
        Me.Hide()
        UserscoreForm.Show()
    End Sub

    Private Sub GameSales_Click(sender As Object, e As EventArgs) Handles GameSales.Click
        Me.Hide()
        SalesForm.Show()
    End Sub

    Private Sub DeveloperRating_Click(sender As Object, e As EventArgs) Handles DeveloperRating.Click
        RatingForm.Show()
        Me.Hide()
    End Sub

    Private Sub CriticScore_Click(sender As Object, e As EventArgs) Handles CriticScore.Click
        Me.Hide()
        CriticscoreForm.Show()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim openFileDialog As New OpenFileDialog()
        openFileDialog.Filter = "CSV Files (*.csv)|*.csv"
        openFileDialog.ShowDialog()

        If openFileDialog.FileName <> "" Then
            Dim dt As New DataTable()
            Dim fileReader As New StreamReader(openFileDialog.FileName)
            Dim line As String = fileReader.ReadLine()
            Dim columns As String() = line.Split(",")
            For Each column As String In columns
                dt.Columns.Add(column.Trim())
            Next
            While Not fileReader.EndOfStream
                line = fileReader.ReadLine()
                Dim fields As String() = line.Split(",")
                dt.Rows.Add(fields)
            End While
            fileReader.Close()
            DataGridView1.DataSource = dt
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim backup As New SaveFileDialog
        backup.InitialDirectory = "C:\"
        backup.Title = "Database Backup"
        backup.CheckFileExists = False
        backup.CheckPathExists = False
        backup.DefaultExt = "sql"
        backup.Filter = "sql files (*.sql)|*.sql|All files (*.*)|*.*"
        backup.RestoreDirectory = True

        If backup.ShowDialog = Windows.Forms.DialogResult.OK Then
            Call Connect_to_DB()
            Dim cmd As MySqlCommand = New MySqlCommand
            cmd.Connection = myconn
            Dim mb As MySqlBackup = New MySqlBackup(cmd)
            mb.ExportToFile(backup.FileName)
            myconn.Close()
            MessageBox.Show("Database Successfully Backup!", "BACKUP", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf backup.ShowDialog = Windows.Forms.DialogResult.Cancel Then
            Return
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        ReportForm.Show()
    End Sub
End Class