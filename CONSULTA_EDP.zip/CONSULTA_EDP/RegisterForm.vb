﻿Imports MySql.Data.MySqlClient

Public Class RegisterForm
    Private Sub cancelbtn_Click(sender As Object, e As EventArgs) Handles cancelbtn.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub registerbtn_Click(sender As Object, e As EventArgs) Handles registerbtn.Click
        Call Connect_to_DB()
        Dim mycmd As New MySqlCommand

        Dim name As String = usernametxt.Text
        Dim password As String = passwordtxt.Text
        Dim email As String = addresstxt.Text
        Dim address As String = emailtxtx.Text

        Dim sql As String = "INSERT INTO users (username, password, address, email) VALUES (@name, @password, @address, @email)"
        mycmd = New MySqlCommand(sql, myconn)

        mycmd.Parameters.AddWithValue("@name", name)
        mycmd.Parameters.AddWithValue("@password", password)
        mycmd.Parameters.AddWithValue("@address", address)
        mycmd.Parameters.AddWithValue("@email", email)
        mycmd.ExecuteNonQuery()
        MessageBox.Show("Account Successfully Created!", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Call Disconnect_to_DB()
        Form1.Show()
        Hide()
    End Sub
End Class